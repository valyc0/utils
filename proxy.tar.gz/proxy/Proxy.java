import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import java.util.logging.*;

public class Proxy {
    private static final Logger LOG = Logger.getLogger("Proxy");
    private static final int BUFSIZE = 8192;

    public static void main(String[] args) throws Exception {
        String bind = "0.0.0.0";
        int port = 3128;

        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "-b":
                case "--bind":
                    bind = args[++i];
                    break;
                case "-p":
                case "--port":
                    port = Integer.parseInt(args[++i]);
                    break;
            }
        }

        LOG.info("Proxy listening on " + bind + ":" + port);
        ServerSocket serverSocket = new ServerSocket(port, 256, InetAddress.getByName(bind));
        ExecutorService executor = Executors.newCachedThreadPool();

        while (true) {
            Socket clientSocket = serverSocket.accept();
            executor.submit(() -> handleClient(clientSocket));
        }
    }

    private static void handleClient(Socket clientSocket) {
        try (clientSocket) {
            clientSocket.setSoTimeout(30000);
            BufferedReader reader = new BufferedReader(
                new InputStreamReader(clientSocket.getInputStream(), StandardCharsets.UTF_8));
            String requestLine = reader.readLine();
            if (requestLine == null) return;

            String[] parts = requestLine.split(" ", 3);
            if (parts.length < 3) return;
            String method = parts[0];
            String target = parts[1];

            if ("CONNECT".equalsIgnoreCase(method)) {
                handleConnect(clientSocket, target);
            } else {
                handleHttp(clientSocket, reader, requestLine, method, target);
            }
        } catch (Exception e) {
            LOG.fine("Client error: " + e.getMessage());
        }
    }

    private static void handleConnect(Socket clientSocket, String target) throws Exception {
        String[] hostPort = target.split(":");
        String host = hostPort[0];
        int port = hostPort.length > 1 ? Integer.parseInt(hostPort[1]) : 443;

        Socket remoteSocket = new Socket();
        try {
            remoteSocket.connect(new InetSocketAddress(host, port), 10000);

            OutputStream out = clientSocket.getOutputStream();
            out.write("HTTP/1.1 200 Connection Established\r\n\r\n".getBytes(StandardCharsets.UTF_8));
            out.flush();

            InputStream remoteIn = remoteSocket.getInputStream();
            OutputStream remoteOut = remoteSocket.getOutputStream();
            InputStream clientIn = clientSocket.getInputStream();

            CountDownLatch latch = new CountDownLatch(2);
            pipe(clientIn, remoteOut, latch);
            pipe(remoteIn, out, latch);
            latch.await();
        } finally {
            remoteSocket.close();
        }
    }

    private static void handleHttp(Socket clientSocket, BufferedReader reader,
                                   String requestLine, String method, String target) throws Exception {
        int idx = target.indexOf("://");
        if (idx == -1) return;
        String rest = target.substring(idx + 3);
        String hostAndPort = rest;
        String path = "/";
        int slashIdx = rest.indexOf('/');
        if (slashIdx != -1) {
            hostAndPort = rest.substring(0, slashIdx);
            path = rest.substring(slashIdx);
        }

        String host;
        int port = 80;
        int colonIdx = hostAndPort.indexOf(':');
        if (colonIdx != -1) {
            host = hostAndPort.substring(0, colonIdx);
            port = Integer.parseInt(hostAndPort.substring(colonIdx + 1));
        } else {
            host = hostAndPort;
        }

        StringBuilder headerLines = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null && !line.isEmpty()) {
            if (!line.toLowerCase().startsWith("proxy-")) {
                headerLines.append(line).append("\r\n");
            }
        }

        Socket remoteSocket = new Socket();
        try {
            remoteSocket.connect(new InetSocketAddress(host, port), 10000);
            remoteSocket.setSoTimeout(30000);

            String request = method + " " + path + " HTTP/1.1\r\n" + headerLines + "\r\n";
            OutputStream remoteOut = remoteSocket.getOutputStream();
            remoteOut.write(request.getBytes(StandardCharsets.UTF_8));
            remoteOut.flush();

            OutputStream clientOut = clientSocket.getOutputStream();
            CountDownLatch latch = new CountDownLatch(1);
            pipe(remoteSocket.getInputStream(), clientOut, latch);
            latch.await();
        } finally {
            remoteSocket.close();
        }
    }

    private static void pipe(InputStream in, OutputStream out, CountDownLatch latch) {
        Thread t = new Thread(() -> {
            try {
                byte[] buffer = new byte[BUFSIZE];
                int read;
                while ((read = in.read(buffer)) != -1) {
                    out.write(buffer, 0, read);
                    out.flush();
                }
            } catch (IOException ignored) {
            } finally {
                latch.countDown();
            }
        });
        t.setDaemon(true);
        t.start();
    }
}
