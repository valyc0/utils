import asyncio, sys, logging, argparse
from asyncio import AbstractEventLoop
from typing import Optional

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("proxy")

BUFSIZE = 8192

async def handle_client(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
    try:
        req = await asyncio.wait_for(reader.readuntil(b"\r\n"), timeout=30)
    except (asyncio.TimeoutError, asyncio.IncompleteReadError):
        writer.close()
        return

    try:
        method, target, _ = req.decode("utf-8", errors="replace").split(" ", 2)
    except ValueError:
        writer.close()
        return

    if method.upper() == "CONNECT":
        await handle_connect(reader, writer, target)
    else:
        await handle_http(reader, writer, req, method, target)

async def handle_connect(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    target: str,
) -> None:
    host_port = target.rstrip("\r\n")
    host, _, port_str = host_port.partition(":")
    try:
        port = int(port_str)
    except ValueError:
        port = 443

    try:
        remote_reader, remote_writer = await asyncio.wait_for(
            asyncio.open_connection(host, port), timeout=10
        )
    except (OSError, asyncio.TimeoutError):
        writer.close()
        return

    writer.write(b"HTTP/1.1 200 Connection Established\r\n\r\n")
    await writer.drain()

    async def pipe(r: asyncio.StreamReader, w: asyncio.StreamWriter) -> None:
        try:
            while not r.at_eof():
                data = await r.read(BUFSIZE)
                if not data:
                    break
                w.write(data)
                await w.drain()
        except (ConnectionResetError, BrokenPipeError, OSError):
            pass
        finally:
            try:
                w.close()
            except OSError:
                pass

    await asyncio.gather(
        pipe(reader, remote_writer),
        pipe(remote_reader, writer),
    )

async def handle_http(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    first_line: bytes,
    method: str,
    target: str,
) -> None:
    from urllib.parse import urlparse

    parsed = urlparse(target)
    host = parsed.hostname
    port = parsed.port or 80
    path = parsed.path or "/"
    if parsed.query:
        path += "?" + parsed.query

    if not host:
        writer.close()
        return

    try:
        remote_reader, remote_writer = await asyncio.wait_for(
            asyncio.open_connection(host, port), timeout=10
        )
    except (OSError, asyncio.TimeoutError):
        writer.close()
        return

    new_req = f"{method} {path} HTTP/1.1\r\n".encode()
    headers = first_line

    try:
        while True:
            line = await asyncio.wait_for(reader.readuntil(b"\r\n"), timeout=30)
            if line == b"\r\n":
                break
            decoded = line.decode("utf-8", errors="replace")
            if decoded.lower().startswith("proxy-"):
                continue
            headers += line
    except (asyncio.TimeoutError, asyncio.IncompleteReadError):
        pass

    remote_writer.write(new_req + headers + b"\r\n")
    await remote_writer.drain()

    async def pipe_response() -> None:
        try:
            while not remote_reader.at_eof():
                data = await remote_reader.read(BUFSIZE)
                if not data:
                    break
                writer.write(data)
                await writer.drain()
        except (ConnectionResetError, BrokenPipeError, OSError):
            pass
        finally:
            try:
                writer.close()
            except OSError:
                pass

    await pipe_response()

async def main() -> None:
    parser = argparse.ArgumentParser(description="HTTP Proxy")
    parser.add_argument("-b", "--bind", default="0.0.0.0", help="Bind address")
    parser.add_argument("-p", "--port", type=int, default=3128, help="Listen port")
    args = parser.parse_args()

    server = await asyncio.start_server(handle_client, args.bind, args.port)
    log.info("Proxy listening on %s:%d", args.bind, args.port)

    async with server:
        await server.serve_forever()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log.info("Shutting down")
